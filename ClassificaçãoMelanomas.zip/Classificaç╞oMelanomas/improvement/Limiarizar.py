import math
import cv2
import numpy as np
from matplotlib import pyplot as plt


def Limiar(img):

    image = cv2.cvtColor(img , cv2.COLOR_BGR2GRAY)
    limiar , imagemOtsu = cv2.threshold(image, 127, 255 ,cv2.THRESH_BINARY_INV +cv2.THRESH_OTSU)
 
    return imagemOtsu