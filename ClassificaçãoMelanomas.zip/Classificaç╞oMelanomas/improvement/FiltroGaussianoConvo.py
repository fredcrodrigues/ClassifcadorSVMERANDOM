import cv2
import numpy as np
import matplotlib.pyplot as plt
import math



def Cconvolucao( img , kernel , average=False ):

    img_row, img_col = img.shape
    kernel_lin, kernel_col = kernel.shape
 #same convolução tipo de te preeenchimento de uma matriz 
    saidaimg = np.zeros(img.shape) # retorna uma matriz preenchidadas com zeros
 
    preenchimento_lin = int((kernel_lin - 1) / 2) # preechimento same convolution f-1/2
    preenchimento_col = int((kernel_col - 1) / 2)
 
    Dimagem = np.zeros((img_row + (2 * preenchimento_lin), img_col + (2 * preenchimento_col))) # cria a dimensão de entrada da imagem n+2p
   
    Dimagem[preenchimento_lin:Dimagem.shape[0] - preenchimento_lin, preenchimento_col:Dimagem.shape[1] -  preenchimento_col] = img # inserir a matriz na imagem
 
   
       
    for lin in range(img_row):
        for col in range(img_col):
           saidaimg[lin, col] = np.sum(kernel * Dimagem[lin:lin + kernel_lin, col:col + kernel_col]) # sma todos os elementos da matriz
           
           if average:
                saidaimg[lin, col] /= kernel.shape[0] * kernel.shape[1]
 
    
 
    return saidaimg

def convolucao( img , Tkernel):
    Kernel = Ckernel( Tkernel , sigma=math.sqrt(Tkernel)) # define o sigma altomaticamente
    resultConvolucao = Cconvolucao(img , Kernel , average=True)

    
    
    return resultConvolucao

def GaussianBlu(img):

    imgSaidaG = cv2.GaussianBlur(img , (21, 21), 0)
    
    return imgSaidaG

def funcG(x, mu, sd ):
     return 1 / (np.sqrt(2 * np.pi) * sd) * np.e ** (-np.power((x - mu) / sd, 2) / 2) # formula do Univariate Normal Distribution , para definir corretamente
 
def Ckernel(size , sigma):
   
    kernel1D = np.linspace(-(size//2), size//2 , size)
    for i in range(size):
        kernel1D[i] = funcG(kernel1D[i] , 0, sigma)
    kernel_2D = np.outer(kernel1D.T, kernel1D.T) # onde forma a matriz multiplicando os arrays
    kernel_2D *= 1.0 / kernel_2D.max()   # 1/kernel maximo 1/225

   
 
    return kernel_2D






