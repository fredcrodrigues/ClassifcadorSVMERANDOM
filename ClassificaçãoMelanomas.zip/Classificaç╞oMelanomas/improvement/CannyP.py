import math
import cv2 
import numpy as np
from . import FiltroGaussianoConvo as fil #importando de outra classe
from matplotlib import pyplot as plt

def histerese(image, Vfo):
    image_lin, image_col = image.shape
 
    pixelTP = image.copy()
 
    for lin in range(1, image_lin):
        for col in range(1, image_col):
            if pixelTP[lin, col] == Vfo:
                if pixelTP[lin, col + 1] == 255 or pixelTP[lin, col - 1] == 255 or pixelTP[lin - 1, col] == 255 or pixelTP[
                    lin + 1, col] == 255 or pixelTP[
                    lin - 1, col - 1] == 255 or pixelTP[lin + 1, col - 1] == 255 or pixelTP[lin - 1, col + 1] == 255 or pixelTP[
                    lin + 1, col + 1] == 255:
                    pixelTP[lin, col] = 255
                else:
                    pixelTP[lin, col] = 0
 
    pixelPB = image.copy()
 
    for lin in range(image_lin - 1, 0, -1):
        for col in range(image_col - 1, 0, -1):
            if pixelPB[lin, col] == Vfo:
                if pixelPB [lin, col + 1] == 255 or pixelPB [lin, col - 1] == 255 or pixelPB [lin - 1, col] == 255 or pixelPB [
                    lin + 1, col] == 255 or pixelPB [
                    lin - 1, col - 1] == 255 or pixelPB [lin + 1, col - 1] == 255 or pixelPB [lin - 1, col + 1] == 255 or pixelPB [
                    lin + 1, col + 1] == 255:
                    pixelPB [lin, col] = 255
                else:
                    pixelPB [lin, col] = 0
 
    pixelPE = image.copy()
 
    for lin in range(1, image_lin):
        for col in range(image_col - 1, 0, -1):
            if pixelPE[lin, col] == Vfo:
                if pixelPE[lin, col + 1] == 255 or pixelPE[lin, col - 1] == 255 or pixelPE[lin - 1, col] == 255 or pixelPE[
                    lin + 1, col] == 255 or pixelPE[
                    lin - 1, col - 1] == 255 or pixelPE[lin + 1, col - 1] == 255 or pixelPE[lin - 1, col + 1] == 255 or pixelPE[
                    lin + 1, col + 1] == 255:
                    pixelPE[lin, col] = 255
                else:
                    pixelPE[lin, col] = 0
 
    pixelPD = image.copy()
 
    for lin in range(image_lin - 1, 0, -1):
        for col in range(1, image_col):
            if pixelPD[lin, col] == Vfo:
                if pixelPD[lin, col + 1] == 255 or pixelPD[lin, col - 1] == 255 or pixelPD[lin - 1, col] == 255 or pixelPD[
                    lin + 1, col] == 255 or pixelPD[
                    lin - 1, col - 1] == 255 or pixelPD[lin + 1, col - 1] == 255 or pixelPD[lin - 1, col + 1] == 255 or pixelPD[
                    lin + 1, col + 1] == 255:
                    pixelPD[lin, col] = 255
                else:
                    pixelPD[lin, col] = 0
 
    final_image =  pixelTP + pixelPB +pixelPE + pixelPD
 
    final_image[final_image > 255] = 255
 
    return final_image


def limiar( imagem,  baixo, alto, Vfo ): ## DEFINIR OS PIXEL DE ACORDO COM AS LIMIARES ESTABELECIDAS 
     
    saidaI = np.zeros(imagem.shape) 

    Vfe = 255 #intesidade

    Vfe_lin , Vfe_col =np.where(imagem >=alto) # verifica os valores da matriz se é maior que o valor da limiar Lh 
    Vfo_lin ,  Vfo_col = np.where((imagem <= alto)&(imagem >= baixo)) # verificar se esta entre Lh ou Lt
    
    saidaI[Vfe_lin, Vfe_col] = Vfe ## DEFINE COMO 255O VALOR DA ARESTA  OU SEJA APROPRIADA 
    saidaI[Vfo_lin , Vfo_col ] = Vfo ## DEFINE COMO 255O VALOR DA ARESTA 
    # OS DEMAIS PIXELS SERÃO ZERO
    return saidaI
 

def naoSupre(magnitudeImage ,  orintacaoGradiente ):
    image_row, image_col = magnitudeImage.shape
    output = np.zeros(magnitudeImage.shape)
    PI = 180
    for row in range(1, image_row - 1): # setores emm graus susgerido por jain
            for col in range(1, image_col - 1):
                direction = orintacaoGradiente[row, col]
    
                if (0 <= direction < PI / 8) or (15 * PI / 8 <= direction <= 2 * PI):
                    before_pixel = magnitudeImage[row, col - 1]
                    after_pixel = magnitudeImage[row, col + 1]
    
                elif (PI / 8 <= direction < 3 * PI / 8) or (9 * PI / 8 <= direction < 11 * PI / 8):
                    before_pixel = magnitudeImage[row + 1, col - 1]
                    after_pixel = magnitudeImage[row - 1, col + 1]
    
                elif (3 * PI / 8 <= direction < 5 * PI / 8) or (11 * PI / 8 <= direction < 13 * PI / 8):
                    before_pixel = magnitudeImage[row - 1, col]
                    after_pixel = magnitudeImage[row + 1, col]
    
                else:
                    before_pixel = magnitudeImage[row - 1, col - 1]
                    after_pixel = magnitudeImage[row + 1, col + 1]
    
                if magnitudeImage[row, col] >= before_pixel and magnitudeImage[row, col] >= after_pixel:
                    output[row, col] = magnitudeImage[row, col]
    
    
    
    return output


def sobel(image , filtroSobel , verbose=False ):
    
    novaimage_vertical = fil.Cconvolucao(image , filtroSobel) # imagem e o filtro sobel , matriz de convolução ,  mascara de gradiente vertical

    novaimage_horizontal = fil.Cconvolucao(image, np.flip(filtroSobel.T, axis=0))# gradiente horizntal

    
    magnitudeImage = np.sqrt(np.square(novaimage_vertical) + np.square(novaimage_horizontal)) # magnitude do gradiente raiz quadrada do gradiente vertica mais o gradiente horizontal

    magnitudeImage *= 255.0 /magnitudeImage.max() #normalização 0 a 255

    orintacaoGradiente = np.arctan2(novaimage_vertical, novaimage_horizontal)
     # converte o resultado em graus
    orintacaoGradiente = np.rad2deg(orintacaoGradiente)
    orintacaoGradiente += 180 

    
    return magnitudeImage , orintacaoGradiente




def cannyprincipal(img):
    filtroSobel = np.array([[-1 , 0  , 1], [-2 , 0 , 2 ], [-1, 0, 1]]) # MASCARA OPERADOR SOBEL

    magnitudeImage , orintacaoGradiente = sobel(img  , filtroSobel)# APLICAR OS OPERADOR OBTEM O GRADIENTE ATRAVES DO OPERADOR SOBEL
    imageSupre =  naoSupre(magnitudeImage , orintacaoGradiente)# VERFICAÇÃO DA MAGNITUDE DO GRADIENTE DE ACORDO COM A DIREÇÃO DO PIXEL EM RELARAÇÃO AO SETOR EM GRAUS
    LimiarImg = limiar(imageSupre , 5 , 20 , 50 )#valores baixo e alto limiar e o valor definido como fraco para atribuir aos pixel
    SaidaImagem = histerese(LimiarImg , 50) ## indetificar os pixel fracos que podem ser arestas
    
   

    return SaidaImagem