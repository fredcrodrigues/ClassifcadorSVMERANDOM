#import cv2
#import numpy as np
#import FiltroGaussianoConvo as conv
#import Limiarizar as limiar
#import Canny as canny
#import matplotlib.pyplot as plt
#from matplotlib.offsetbox import AnchoredText



#imagem = cv2.imread("img/nov.jpg") ##
#imgCinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY) 
#imagemConv = conv.GaussianBlur(imgCinza)
#imagemLimiar = limiar.Limiar(imagemConv)
#imagemcanny  =(imagemLimiar , 100 , 200)

#contours,hierarchy = cv2.findContours(imagemLimiar,2,1)
#print (len(contours))
#cnt = contours

#for i in range (len(cnt)):
 #   (x,y),radius = cv2.minEnclosingCircle(cnt[i])
  #  center = (int(x),int(y))
   # radius = int(radius)
    #cv2.circle(imagemLimiar,center,radius,(0,255,0),2)
    #print ('Circle: ' + str(i) + ' - Center: ' + str(center) + ' -     Radius: ' + str(radius))
#plt.text(x-15, y+10, '+', fontsize=25, color = 'red')
#plt.text(10, -10, 'Centro: '+str(center), fontsize=11, color = 'red')
#plt.text(340, -10, ' Diametroo: '+str((radius*2)/100)+'mm', fontsize=11, color = 'red')
#plt.Circle(x, y, color='red', fill=False)
#plt.imshow(imagemLimiar, cmap='gray')
#plt.show()