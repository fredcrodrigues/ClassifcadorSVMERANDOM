
import h5py
import numpy as np
import os
import glob
import cv2
import warnings

import globa as gl 

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler

from matplotlib import pyplot
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report

## classificadores de test
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC 


#from sklearn.tree import export_graphviz
#from sklearn.externals.six import StringIO  
#from IPython.display import Image  
#import pydotplus

from sklearn.utils import _joblib
from sklearn import metrics
from sklearn.metrics import accuracy_score

warnings.filterwarnings('ignore') # avisos


num_trees = 100
test_size = 0.10  # teste
seed      = 9 # k- folds
caminho_train  = "dataset/train"
caminho_test  = "dataset/test"
h5_data    = 'output/data.h5'
h5_labels  = 'output/labels.h5'
scoring    = "accuracy"

# Obtem rotulos

train_rotulo = os.listdir(caminho_train)

# Ordenar rotulos
train_rotulo.sort()

if not os.path.exists(caminho_test): ## verificar se o caminho exite ou não
    os.makedirs(caminho_test)

# Criar modelos de treinamento
models = []

models.append(('RF', RandomForestClassifier(n_estimators=num_trees, random_state=seed)))
models.append(('SVM', SVC(random_state=seed)))

# armazenar resultados
results = []
names   = []

# importar vetor de recursos 
h5f_data  = h5py.File(h5_data, 'r')
h5f_label = h5py.File(h5_labels, 'r')

global_caracter_string = h5f_data['dataset_1']
global_labels_string   = h5f_label['dataset_1']

global_caracters = np.array(global_caracter_string)
global_labels   = np.array(global_labels_string)

h5f_data.close()
h5f_label.close()

# Forma do vetor e dos rotulos
print("[STATUS] tam caracettristicas: {}".format(global_caracters.shape))
print("[STATUS] Nomes rotulos: {}".format(global_labels.shape))

print("[STATUS] treinamento inciado...")

# Divisão de dados treinamento e teste
(trainDataGlobal, testDataGlobal, trainLabelsGlobal, testLabelsGlobal) = train_test_split(np.array(global_caracters),## divide
                                                                                          np.array(global_labels),
                                                                                          test_size=test_size,
                                                                                          random_state=seed) #semente do gerador

print("[STATUS] Divisão...")
print("Dados de treino : {}".format(trainDataGlobal.shape))
print("Dados de teste   : {}".format(testDataGlobal.shape))
print("Nomes de  treino: {}".format(trainLabelsGlobal.shape))
print("Nomes de teste : {}".format(testLabelsGlobal.shape))

#/### comparção
for name, model in models:
    kfold = KFold(n_splits=9, random_state=seed)
    cv_results = cross_val_score(model, trainDataGlobal, trainLabelsGlobal, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# boxplot algorithm comparison
fig = pyplot.figure()
fig.suptitle('Comparação de classifcadores')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
pyplot.show()


#Testar modelo

import matplotlib.pyplot as plt

# Radom 
#clf  = RandomForestClassifier(n_estimators=num_trees, random_state=seed)
clf = SVC(C=100.0, random_state=seed)

clf.fit(trainDataGlobal, trainLabelsGlobal) #, ajustar dados

pred = clf.predict(testDataGlobal)

print(testDataGlobal.shape)
print(pred.shape)

#calculo da metrica 
print("Acuracia:",metrics.accuracy_score(testLabelsGlobal, pred)*100)

#Visualizar todas as metricas#
print(classification_report(testLabelsGlobal, pred))



# teste de imagens
for file in glob.glob(caminho_test + "/*.jpg"):
    # carrega
    image = cv2.imread(file)

    #tamanho da imagem saida
    image = cv2.resize(image, tuple((500, 500)))

    ####################################
    # Extração de caracteristicas
    ####################################
    fv_hu_moments = gl.fd_hu_moments(image)
    fv_lbp  = gl.fd_lbp(image)
    fv_histogram  = gl.fd_histogram(image)

    
    # CONCATENA CARACTERISTICAS
   
    global_caracter = np.hstack([fv_hu_moments ,  fv_lbp  , fv_histogram])

    # Transformar recursos para determinado intervalo 01
    scaler = MinMaxScaler(feature_range=(0, 1))
    rescaled_caracter = scaler.fit_transform(global_caracter.reshape(-1,1))

    # previsão imagem teste
    
    previsao = clf.predict(rescaled_caracter.reshape(1,-1))[0]

    # nome
    cv2.putText(image, train_rotulo[previsao], (20,30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,255,255), 3)

    # saida
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    plt.show()