#-----------------------------------
# EXTRAÇÃO DE CARACTERISTICAS
#-----------------------------------
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import mahotas
import cv2
import os
import h5py # FORMATO h5py
from improvement import FiltroGaussianoConvo as fil
from descritor.localbinarypatterns import LocalBinaryPatterns # projetados para organizar e armazenar grande quantidades de dados 
import MaskSegm as makS
import mahotas as mh


images_per_class = 40 # quantidade de imagens por classe
tamanho_fixo     = tuple((500, 500))## converter a imagem em um tamanho fixo
caminho_train     = "dataset/train"
h5_data          = 'output/data.h5'
h5_labels        = 'output/labels.h5'
bins             = 8 # hitograma

# descritor de caracteristicas HU MOMENTOS
def fd_hu_moments(image):
    imagem  = makS.contorno(image)  # MASCARA DE SEMMENTAÇÃO  
    
    Nimagem = cv2.cvtColor(imagem , cv2.COLOR_BGR2GRAY) 

    caractr = cv2.HuMoments(cv2.moments(Nimagem)).flatten() # MMOMENTO DE HU copia da matriz
    #moments =  mh.features.zernike_moments(Nimagem , 21)
    return  caractr 


def fd_lbp(image):
    
    desc = LocalBinaryPatterns(24 , 8)

    imagem  = makS.contorno(image)  

    Nimagem = cv2.cvtColor(imagem , cv2.COLOR_BGR2GRAY)

    histo = desc.describe(Nimagem) # chama a classe do descritor
   
    return histo


def fd_histogram(image, mask=None):
    
    imagem  = makS.contorno(image)

    Nimagem = cv2.cvtColor(imagem, cv2.COLOR_BGR2RGB)
  
    hist  = cv2.calcHist([Nimagem], [0, 1, 2], None, [bins, bins, bins], [0, 256, 0, 256, 0, 256]) ## hitorgrama de
  
    cv2.normalize(hist, hist) ## probabilidade de cada valor
    
    return hist.flatten()

#obeter rotulos de treinamento
train_rotulos = os.listdir(caminho_train) 

# classificar rótulos de treinamento
train_rotulos.sort()
print(train_rotulos)

# Listas para ter o vetor 
global_caracteristicas = []
labels          = []

# Loop sobre as subpastas de treinamento
for treina_nome in train_rotulos :
    # juntar ao caminho dos dados de treinamento  e nome
    dir = os.path.join(caminho_train,  treina_nome)

    # get the current training label
    atual_rotulo =  treina_nome

    # Loop sobre as imagens
    for x in range(1,images_per_class+1):
        # get the image file name
        file = dir + "/" + str(x) + ".jpg"

        # tamanho fixo imagem
        image = cv2.imread(file)
        image = cv2.resize(image, tamanho_fixo )

    
        # EXTRAÇÃO DE CARACTERISTICAS
        
        fv_hu_moments = fd_hu_moments(image)
        fv_lpb   = fd_lbp(image)
        fv_histogram  = fd_histogram(image)

      
        # CONCATENA OS RECURSSO EXTRAIDOS
      
        global_caracteristica = np.hstack([fv_hu_moments , fv_lpb  ,  fv_histogram ])#,# fv_hu_moments])

        # Atualizar
        labels.append(atual_rotulo)
        global_caracteristicas.append(global_caracteristica)

    print("[STATUS] Processando Pasta de treinamento: {}".format(atual_rotulo))

print("[STATUS] Completo a extração de caracteristicas...")

# tamanho do vetor
print("[STATUS] Tamanho do vetor de rcuros {}".format(np.array(global_caracteristicas).shape))

# tamanho 
print("[STATUS] Qauntidade de imagens treinadas {}".format(np.array(labels).shape))

#destino e salvar nomes
NomesDest = np.unique(labels)
le          = LabelEncoder()
cod     = le.fit_transform(labels)
print("[STATUS] Treino codificado...")

# recurso entre zero e um
scaler            = MinMaxScaler(feature_range=(0, 1))
rescaled_caracter = scaler.fit_transform(global_caracteristicas)
print("[STATUS] caracteristicas normalizadas...")

print("[STATUS] Codigo de destino: {}".format(cod))
print("[STATUS] Quatidades de imagens de treino codifcados: {}".format(cod.shape))

# salva vetor de recurso hdfg5
h5f_data = h5py.File(h5_data, 'w')
h5f_data.create_dataset('dataset_1', data=np.array(rescaled_caracter))

h5f_label = h5py.File(h5_labels, 'w')
h5f_label.create_dataset('dataset_1', data=np.array(cod))

h5f_data.close()
h5f_label.close()

print("[STATUS] Trainamento finalizado..")