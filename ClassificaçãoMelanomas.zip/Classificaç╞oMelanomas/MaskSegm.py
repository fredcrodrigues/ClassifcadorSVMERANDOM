import cv2
import numpy as np
from improvement import Limiarizar as th
from improvement import FiltroGaussianoConvo  as filt
from improvement import kmeans as kme


def contorno(img):
   # img = cv2.imread("dataset/testing/9.jpg")
  filtro = filt.GaussianBlu(img)
  seg = kme.kmeans(img)
  Limiar = th.Limiar(seg)
    #gray_img = cv2.cvtColor(filtro , cv2.COLOR_BGR2GRAY)
    #_, thresh = cv2.threshold(gray_img , 127, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    #cv2.imshow("Limiar e",Limiar) testes
  img_contours = cv2.findContours(Limiar, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)[-2]
  img_contours = sorted(img_contours, key=cv2.contourArea)

  for i in img_contours:     
    if cv2.contourArea(i) > 20000:    
      break 

  mask = np.zeros(img.shape[:2], np.uint8)
  cv2.drawContours(mask, [i],-1, 255, -1)
  novaimg = cv2.bitwise_and(img, img, mask=mask)

  return novaimg
  # cv2.imshow("saida" ,novaimg )
  #cv2.waitKey(0)