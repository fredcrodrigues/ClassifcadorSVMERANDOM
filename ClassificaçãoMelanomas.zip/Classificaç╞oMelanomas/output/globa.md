This is the folder where your extracted global features are stored.

This folder will have 2 files.
  --data.h5
  --labels.h5